package com.example.mymovie_1.utills;

public class Define {
    public static String BASE_URL ="https://yts.lt/api/v2/";
    public static String PAGE_TITLE_MOVIE = "MOVIE";
//    public static String CHANE_TOP_BAR_NAME = "INFO";
    public  static String PAGE_TITLE_INFO = "INFO";

}
