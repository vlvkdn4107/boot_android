package com.example.mymovie_1.interfaces;

import com.example.mymovie_1.utills.FragmentType;

public interface OnInfoItemClicked {
    void setTitleAppBar(String title);
}
