package com.example.mymovie_1.utills;

public enum FragmentType {
    MOVIE, INFO
}
